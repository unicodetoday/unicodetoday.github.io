﻿===ZawGyi===
** Windows 7 Office အားလုံး**
Pyidaungsu 1.8.x  ကိုထည့္သြင္းရပါမည္။

**Windows 10 Office 2010 ႏွင့္ေအာက္အသုံးျပဳလွ်င္**
Pyidaungsu 1.8.x  ကိုထည့္သြင္းရပါမည္။

** Windows 10 Office 2013 ႏွင့္အထက္ကို အသုံးျပဳလွ်င္**
Pyidaungsu 2.5.x ကိုထည့္သြင္းရပါမည္။
Myanmar3-2018 ကိုထည့္သြင္းလိုက ထည့္သြင္းႏိုင္ပါသည္။

**စာမ်က္ႏွာ နံပါတ္တပ္ရန္**
Pyidaungsu Number font ကိုထည့္သြင္းႏိုင္ပါသည္။

===Unicode===
** Windows 7 Office အားလုံး**
Pyidaungsu 1.8.x  ကိုထည့်သွင်းရပါမည်။

**Windows 10 Office 2010 နှင့်အောက်အသုံးပြုလျှင်**
Pyidaungsu 1.8.x  ကိုထည့်သွင်းရပါမည်။

** Windows 10 Office 2013 နှင့်အထက်ကို အသုံးပြုလျှင်**
Pyidaungsu 2.5.x ကိုထည့်သွင်းရပါမည်။
Myanmar3-2018 ကိုထည့်သွင်းလိုက ထည့်သွင်းနိုင်ပါသည်။

**စာမျက်နှာ နံပါတ်တပ်ရန်**
Pyidaungsu Number font ကိုထည့်သွင်းနိုင်ပါသည်။

Phone, viber 09 455 736 999